---
name: presentation-creator
description: Create polished, mode-aware PowerPoint presentations with a clear narrative arc and consistent visual design. Use this skill whenever the user asks for a presentation, slide deck, slides, PowerPoint, .pptx, pitch deck, academic talk, executive briefing, training deck, or marketing slides — even if they don't specify a style. Especially trigger when the user provides source material (notes, PDFs, articles, transcripts) and wants slides built from it (NotebookLM-style), or when they name an audience (investors, executives, students, peers) implying a particular presentation mode. Supports modes — informative, academic, pitch, executive briefing, training, creative/marketing — and lets users define custom modes. Lets the user pick visual richness (rich / moderate / minimal). This skill plans content + design; it then calls the `pptx` skill for actual file generation.
---

# Presentation Creator

A skill for planning and writing the *content* of a presentation with a coherent narrative arc and consistent style. The `pptx` skill handles file generation; this skill decides what goes on the slides and how it should feel.

## When to use this skill

Use this skill whenever the user wants slides — even a casual "make me a deck on X." It pairs with the `pptx` skill: this one plans, that one builds.

If the user only asks to *read* or *edit* an existing .pptx (extract text, fix a typo), skip this skill and go straight to `pptx`. This skill is for authoring new presentations or substantially restructuring existing ones.

## High-level workflow

1. **Capture intent** — gather the inputs (topic? source material? both?), pick a mode, pick visual richness, decide on slide count.
2. **Process source material** if provided — build a fact inventory grounded in the sources.
3. **Draft the outline** — slide-by-slide titles + one-line descriptions, following the mode's narrative arc. Show this to the user before writing full content for any non-trivial deck.
4. **Write slide content** — titles, body, image/chart briefs. Speaker notes only if the user asked.
5. **Hand off to `pptx`** — read `/mnt/skills/public/pptx/SKILL.md` and use it to generate the file, applying the visual richness level chosen.
6. **Present** the file via `present_files`.

## Step 1: Capture intent

Ask only what's missing — don't re-ask things the user already specified. The minimum needed:

- **Topic and/or source material.** If sources are provided, read them before asking further questions; the topic may already be obvious.
- **Mode.** If the user named one (e.g., "pitch deck"), use it. If not, suggest one based on context (audience, purpose) and confirm. Offer "custom" as an option.
- **Visual richness** — Rich / Moderate / Minimal. Default to Moderate unless the mode strongly suggests otherwise (Pitch and Creative default to Rich, Executive to Moderate, Academic to Moderate-with-charts).
- **Slide count** — use the mode's default range unless the user specifies. Don't haggle over exact count; pick a sensible number and adjust if the content demands.
- **Speaker notes?** Default no. Only generate if the user asks.
- **Branding / constraints** — colors, logo, fonts, language. Worth asking once if it might apply (e.g., "any brand colors I should use?") but don't belabor it.
- **Author and affiliation** — when source material has named authors (research papers, reports), use them on the title slide unless the user says otherwise. Same for institutional affiliations. Don't leave these as `[Your Name]` placeholders if the source already supplies them.

## Step 2: Process source material (if provided)

When the user provides sources (PDFs, docs, transcripts, articles, notes):

1. **Read everything thoroughly first.** Don't skim.
2. **Build a fact inventory.** For every concrete claim that might appear on a slide, note where it came from in the source. This isn't a formal bibliography — it's a mental check that every slide claim traces back somewhere.
3. **Find the natural narrative within the sources.** Don't force an unrelated structure on top of them. If the source is a research paper, the academic arc fits naturally. If it's meeting notes, an executive briefing arc probably fits. The mode should match what the material actually is, unless the user has a specific reason otherwise.
4. **Flag gaps.** If the chosen mode needs information not in the sources (e.g., pitch needs market size but the source doesn't have it), either ask the user or mark "[needs source]" in the draft outline.

When **no** source material is given:

- Use general knowledge confidently but accurately.
- **Be careful with numbers.** Statistics, percentages, and specific dates are easy to hallucinate. Either omit them, qualify them ("roughly," "around"), or tell the user what numbers to verify.
- Flag uncertainty rather than fabricate.
- **Special case — Academic mode without sources.** Academic mode is data-heavy by design (charts, tables, citations). Without source material, charts can only be illustrative or absent, and the References slide will be empty. Tell the user this up front and ask if they want to provide papers/data, accept a less data-heavy version, or switch to Informative mode (which works well with general-knowledge content).

## Step 3: Draft the outline

Before writing full slide content, sketch a slide-by-slide outline — titles plus a one-line description per slide:

```
Slide 1: [Title slide] — Deck title + subtitle
Slide 2: [Hook] — Opens with the surprising stat about X
Slide 3: [Problem] — Why current approaches fail
...
```

For any deck longer than ~8 slides, this outline step is non-negotiable for *you* (the skill-runner) — it's much cheaper to fix structure here than to rewrite filled-out slides.

**When to show the outline to the user before proceeding:**
- The structure is bespoke or unusual (e.g., custom mode, mixed-mode deck, multiple sources being woven together).
- Significant content trade-offs need user input (e.g., "do you want to include the limitations section or save it for Q&A?").
- The user's request is ambiguous about scope or emphasis.

**When to proceed without showing the outline first:**
- The structure is standard for the chosen mode (thesis defense, classic Sequoia pitch deck, BLUF executive briefing, training session). The user knows what to expect; reviewing a predictable outline wastes their time.
- The user has been directive about what they want and the path is clear.

When in doubt, proceed but mention the structure briefly in your reply ("I'm using the standard pitch arc — problem, solution, market, ..."), so the user can redirect if needed.

## Step 4: Write slide content

For each slide, produce:

- **Title** — short and concrete. Avoid vague titles like "Overview" or "Introduction."
- **Body** — bullets, short paragraphs, or single statements depending on mode. Keep text terse. The audience reads slides faster than the presenter speaks.
- **Visual brief** — describe what should appear visually. For images: `[IMAGE: photo of solar panels in a desert, wide shot, golden hour]`. For charts: specify the data and chart type. For diagrams: describe the structure.
- **Speaker notes** *(only if requested)* — what the presenter should say or emphasize, transitions, anything not on the slide.

**Reconstructed charts must carry a caveat.** When a chart's *shape* is reconstructed from a source figure rather than plotted from raw data (because the raw data isn't available, only the figure), include a small italicised caption like *"Illustrative — reconstructed from Fig. X of [source]."* This applies to any chart where the y-values are inferred visually from a published figure. Charts plotted from real numerical data in tables or text don't need this caveat.

**When content is short for a widescreen slide, add visual weight rather than leaving empty space.** A slide with three bullets on a 13.3" × 7.5" canvas can look sparse and amateurish. Options to add density:

- Bump body text to 18–22pt (instead of the default 14–16pt).
- Add a related chart, table, or stat callout to the right of the bullets.
- Use a card grid (2×2 or 3×1) instead of a bullet list — visually denser without adding words.
- Add a callout quote, key takeaway box, or "Why this matters" sidebar.
- Split the slide into a two-column layout with a visual element on one side.

Empty bottom thirds of slides are an AI-slop tell. Fix them.

---

## Modes

Each mode defines audience, tone, narrative arc, default slide count, and content style. Use the arc as a structural guide, not a rigid template — adapt to what the actual content needs.

### Informative

For: general audiences, curious learners, public talks, explainers.
Tone: clear, friendly, neutral. No hype, no jargon-without-explanation.
Default count: 10–15 slides.

**Arc:**
1. Hook — a question, surprising fact, or vivid example that opens the topic
2. What it is — define the subject in plain language
3. How it works / why it happens — the mechanism or context
4. Why it matters — relevance to the audience's life
5. Examples or case studies — make it concrete
6. Takeaways — 2–4 things to remember

Style: balanced text + supporting visuals. Bullet points are fine but vary the layout (some slides text-heavy, some image-led).

### Academic

For: peers, researchers, students at a conference, lectures, defenses.
Tone: formal, precise, evidence-backed. Cautious claims.
Default count: 12–20 slides.

**Arc:**
1. Title slide — title, authors, affiliation, date/venue
2. Background / motivation — why this question matters in the field
3. Research question or hypothesis
4. Related work — brief positioning
5. Methods — enough detail to be credible, not exhaustive
6. Results — the core of the deck; multiple slides if needed
7. Discussion — what the results mean
8. Limitations — honest caveats
9. Conclusion / future work
10. References — citations of any sources used

Style: data-heavy. Charts and tables over prose. Sparse text. Use proper citation format throughout.

**If no source material is provided:** the References slide will be empty or near-empty, which is a poor closer for an academic talk. Replace it with a "Further reading," "Discussion," or "Questions" slide instead. Better still, surface the no-sources tension at intent capture (see Step 2's special-case note).

### Pitch

For: investors, buyers, decision-makers being asked for something.
Tone: confident, persuasive, narrative-driven. Big claims, but defensible.
Default count: 10–12 slides.

**Arc (classic Sequoia-style; adapt as needed):**
1. Vision / hook — one-line promise of what's possible
2. Problem — what's broken, who hurts
3. Solution — your answer, in plain terms
4. Why now — what changed in the world that makes this possible
5. Market — size and shape of the opportunity
6. Product — what it actually is, demo or screenshots
7. Traction / proof — numbers, customers, growth
8. Business model — how money is made
9. Team — why you're the ones to do it
10. Ask — what you want from the audience (funding, partnership, decision)

Style: big visuals, minimal text per slide. Each slide has one job. Bold typography, image-led where possible.

### Executive Briefing

For: leadership, busy stakeholders, decision-makers who need to act.
Tone: direct, BLUF (bottom line up front). Respectful of their time.
Default count: 5–8 slides.

**Arc:**
1. TL;DR — the recommendation or finding in one slide
2. Context — minimum needed for the decision
3. Findings or analysis — what we learned
4. Options or recommendations — clearly framed
5. Risks / tradeoffs — what could go wrong
6. Next steps + asks — who does what by when

Style: scannable, dense but well-organized. Tables and structured comparisons over flowing prose. Save flair for the title slide; the rest should feel like a memo with charts.

### Training / Instructional

For: learners, new hires, workshop attendees.
Tone: warm, structured, encouraging. Assumes the audience is new to the material.
Default count: 15–25 slides (depends heavily on session length).

**Arc:**
1. Welcome + objectives — what they'll be able to do by the end
2. Concept chunk 1 — introduce, then illustrate, then check understanding
3. Concept chunk 2 — same pattern, building on chunk 1
4. (Repeat chunks as needed)
5. Walkthrough or demo — apply the concepts to a concrete case
6. Practice prompt — "Now you try X"
7. Recap — revisit the objectives and confirm
8. Resources / next steps — where to learn more

Style: progressive complexity. Visuals show steps, processes, before/after. Repetition of key terms. Avoid information dumps — chunk and pace.

### Creative / Marketing

For: campaign launches, brand reveals, internal hype, press.
Tone: bold, evocative, brand-forward. Story over information.
Default count: 8–12 slides.

**Arc:**
1. Hook — provocative statement, image, or question
2. Story / human truth — the insight behind the campaign
3. Tension — what's at stake or unresolved
4. The idea — your creative answer, big and simple
5. Manifestation — how it shows up (executions, channels)
6. Call to action — what happens next

Style: image-led, big typography, minimal copy. One thought per slide. Treat each slide like a magazine spread.

### Custom

If the user wants something that doesn't fit the above (e.g., a wedding toast deck, a postmortem, a fan presentation), ask:

- Who's the audience?
- What's the tone?
- What's the structure / narrative arc? (If they don't know, suggest one and adapt.)
- Roughly how many slides?
- Any visual style they want?

Then proceed normally with the answers as the mode definition.

---

## Visual richness

The user picks one. This affects how aggressively the `pptx` skill should apply visual treatment.

### Rich

- Image placeholders on most slides (with descriptive briefs)
- Diagrams (flowcharts, hierarchies, comparisons) where concepts benefit
- Charts for any quantitative data
- Decorative elements: color blocks, icons, accent shapes
- Use the full design vocabulary in `pptx`'s "Design Ideas" section

Best for: Pitch, Creative/Marketing, public talks where you want to wow.

### Moderate (default)

- Charts for quantitative data
- Diagrams only where genuinely clarifying (don't decorate for its own sake)
- Otherwise clean, typography-driven slides
- Restrained color palette, occasional accent visuals

Best for: Informative, Academic, Executive Briefing, Training.

### Minimal

- Typography-led design — strong type hierarchy, generous whitespace
- No decorative images
- Charts only when essential to the argument
- Two-color palette at most

Best for: when the user wants something that feels editorial, premium, or text-respecting (e.g., a literary talk, a philosophy lecture, a font-nerd presentation about typography).

---

## Source grounding (NotebookLM-style)

When source material is provided, follow these rules to avoid hallucination:

1. **Build from sources outward, not topic inward.** Open with what the source actually says, then structure around that. Don't draft a generic outline first and then look for source material to fill it in — that's how invented "facts" sneak in.

2. **Every concrete claim should trace to the source.** Numbers, dates, names, quotes, technical specifics — if it's not in the source, don't put it on a slide unless the user is told it's general knowledge.

3. **When you need something the source doesn't have**, you have three options, in order of preference:
   - Restructure the deck so you don't need it.
   - Ask the user.
   - Mark it `[needs source]` in the outline and leave it for the user to fill in.

4. **For Academic mode, cite properly.** Each claim from a source should reference its location (page, section, or full citation on a references slide).

5. **Include a Sources slide at the end** for any deck that draws on external material, even informal ones. List what was used.

6. **Distinguish "from the source" from "general knowledge inference."** If you're connecting two source claims with a connector that's your own reasoning, that's fine — but be aware of which parts are which, and don't present inferences as if they were stated in the source.

---

## Visual consistency rules

For NotebookLM-style polish, these apply across every deck regardless of mode:

- **One title style throughout.** Same font, size, position. Don't mix.
- **Consistent layout patterns.** A "two-column" slide should look like the other two-column slides. Don't reinvent per slide.
- **Constrained palette.** 3–4 colors maximum: 1 primary (60–70% visual weight), 1 accent, 1–2 neutrals. Pick colors informed by the topic — see `pptx`'s palette suggestions.
- **One or two fonts.** A header font with personality + a clean body font, OR a single font in different weights.
- **Generous spacing.** Never cramped. 0.5" minimum margins, 0.3–0.5" between content blocks.
- **One focus per slide.** If a slide is trying to make two points, split it.

The `pptx` skill's "Design Ideas" and "Avoid (Common Mistakes)" sections are authoritative for visual rendering — read them before generating the file.

---

## Hand-off to `pptx`

Once the outline + slide content + visual richness are settled:

1. Read `/mnt/skills/public/pptx/SKILL.md` if not already loaded.
2. Decide which `pptx` path applies — usually "Create from scratch" via `pptxgenjs`.
3. Generate the .pptx, applying:
   - The mode's content (titles + bodies + image briefs) you wrote in Step 4.
   - A topic-informed color palette and font pairing from `pptx`'s suggestions.
   - Visual treatment scaled to the chosen richness level.
   - Speaker notes if requested.
4. Run `pptx`'s required QA steps (text extraction, visual inspection).
5. Save to `/mnt/user-data/outputs/` and call `present_files`.

When generating image placeholders, leave them as descriptive text the user can replace later (or use real image search/generation if those tools are available in the session).

---

## Quick decision aid

| User says... | Likely mode | Default richness |
|---|---|---|
| "investor deck", "raise", "VC", "seed/Series A" | Pitch | Rich |
| "for my professor", "thesis defense", "conference talk" | Academic | Moderate |
| "for the leadership team", "board update", "C-suite" | Executive Briefing | Moderate |
| "explain X to my class", "intro to", "for a general audience" | Informative | Moderate |
| "onboarding", "training", "workshop", "teach the team" | Training | Moderate |
| "campaign", "brand", "launch", "marketing" | Creative/Marketing | Rich |

If unsure, ask. Don't guess on tone — pitch tone in an academic context is a disaster.
